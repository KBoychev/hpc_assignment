clear all;
close all;
clc;

N_e=4;
L=10.0; %m
l=L/N_e; %m
A=0.1*0.12; %m2
I=(0.1*0.12^3)/12; %m4
E=2.1*10^11; %Pa
rho=7850; %kg/m3




r_e=6;
c_e=6;

K_e=zeros(r_e,c_e);
M_e=zeros(r_e,c_e);
F_e=zeros(r_e,1);

%% Set M_e
% ------------------------------------------------------------

for i=1:r_e
    for j=i:c_e
        
        M_e(i,j)=0;
        
        if i==j
            
            if i==3 || i==6
                M_e(i,j)=rho*A*l^3*1/24;
            else 
                M_e(i,j)=rho*A*l*1/2;
            end  
            
        end
    end
end

fprintf('%ix%i [M_e]=\n',r_e,c_e);
disp(M_e);
    
 %% Set K_e
 % ------------------------------------------------------------
    
for i=1:r_e
    for j=i:c_e
        
        K_e(i,j)=0;
        
        if i==j
            
            if i==1 || i==4
                K_e(i,j)=(A*E)/l;
            end
            
            if i==2 || i==5
                K_e(i,j)=(12*E*I)/l^3;
            end
            
            if i==3 || i==6
                K_e(i,j)=(4*E*I)/l;
            end
   
        end
        
        if i==1 && j==4
            K_e(i,j)=-(A*E)/l;
        end
        
        if i==2 && j==3
            K_e(i,j)=(6*E*I)/l^2;
        end
        
        if i==2 && j==5
            K_e(i,j)=-(12*E*I)/l^3;
        end
        
        if i==2 && j==6
            K_e(i,j)=(6*E*I)/l^2;
        end
        
        if i==3 && j==5
            K_e(i,j)=-(6*E*I)/l^2;
        end
        
        if i==3 && j==6
            K_e(i,j)=(2*E*I)/l;
        end
        
         if i==5 && j==6
            K_e(i,j)=-(6*E*I)/l^2;
        end
        
        if j~=i
            K_e(j,i)=K_e(i,j);
        end
        
    end
end

fprintf('%ix%i [K_e]=\n',r_e,c_e);
disp(K_e);


r=3*(N_e+1);
c=3*(N_e+1);

K=zeros(r,c);
M=zeros(r,c);



%% Assemble M
% ------------------------------------------------------------

for k=1:N_e

        M((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)))=M_e+M((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)));
 
end


%% Assemble K
% ------------------------------------------------------------

for k=1:N_e

        K((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)))=K_e+K((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)));
  
end

K(1,:)=0; 
K(2,:)=0;
K(3,:)=0;
K(r-2,:)=0;
K(r-1,:)=0;
K(r,:)=0;

K(1,1)=1;
K(2,2)=1;
K(3,3)=1;
K(r-2,r-2)=1;
K(r-1,r-1)=1;
K(r,r)=1;





%Implicit
%--------------------------

T=1; %s
N_t=500;
dt=T/(N_t-1);


F=zeros(r,1);
u=zeros(r,1);
u_t=zeros(r,1);
u_tt=zeros(r,1);
u_p=zeros(r,1);
u_pk=zeros(r,1);
u_t_p=zeros(r,1);
u_tt_p=zeros(r,1);

K_eff=1/(0.25*dt^2)*M+K;
K_eff_inv=inv(K_eff);


tic;

fprintf('Implicit\n------------------------------------------------------------\n');

t=0;
for n=1:N_t

    for k=2:N_e

        F((k-1)*3+1)=0;

        F((k-1)*3+3)=0;

        if k==(N_e/2+1) 
            F((k-1)*3+2)=t*1000/T*(l+1);
        else
            F((k-1)*3+2)=t*1000/T*l;
        end
    end
    
    b=F+M*(1/(0.25*dt^2)*u+1/(0.25*dt)*u_t+(1/(2*0.25)-1)*u_tt);

    R=1;

    k=0;

    while R > 1*10^(-12)

        for i=1:r
          sigma=0;
          for j=1:r
            if j<=i-1
              sigma = sigma + K_eff(i,j)*u_pk(j);
            end
            if j>=i+1
              sigma = sigma + K_eff(i,j)*u_p(j);
            end
          end

          u_pk(i)=1/K_eff(i,i)*(b(i)-sigma);
        end

        R=abs(sum(u_pk-u_p));

        u_p=u_pk;
        k=k+1;
    end
    
    u_tt_p=1/(0.25*dt^2)*(u_p-u)-1/(0.25*dt)*u_t-(1/(2*0.25)-1)*u_tt;
    
    u_t_p=u_t+dt*0.5*u_tt+dt*0.5*u_tt_p;
    
    u=u_p;
    u_t=u_t_p;
    u_tt=u_tt_p;
    
    t=t+dt;
end


disp(u);

fprintf('Operation took %0.4f s.\n',toc);

%Implicit parallel
%--------------------------

tic;

fprintf('Implicit parallel\n------------------------------------------------------------\n');

r_p=N_e/2*3;

K_eff1=K_eff(4:(r_p+3),4:(r_p+3));
M1=M(4:(r_p+3),4:(r_p+3));

F1=zeros(r_p,1);
u1=zeros(r_p,1);
u_t1=zeros(r_p,1);
u_tt1=zeros(r_p,1);
u_p1=zeros(r_p,1);
u_pk1=zeros(r_p,1);
u_t_p1=zeros(r_p,1);
u_tt_p1=zeros(r_p,1);


F2=zeros(r_p,1);
u2=zeros(r_p,1);
u_t2=zeros(r_p,1);
u_tt2=zeros(r_p,1);
u_p2=zeros(r_p,1);
u_pk2=zeros(r_p,1);
u_t_p2=zeros(r_p,1);
u_tt_p2=zeros(r_p,1);



t=0;
for n=1:N_t
    
    t=t+dt;

    for k=2:N_e/2+1

        F1((k-2)*3+1)=0;
        F2((k-2)*3+1)=0;

        F1((k-2)*3+3)=0;
        F2((k-2)*3+3)=0;

        if k==(N_e/2+1) 
            F1((k-2)*3+2)=t*1000/T*(l+1);
        else
            F1((k-2)*3+2)=t*1000/T*l;
        end
        
        if k==2
            F2((k-2)*3+2)=t*1000/T*(l+1);
        else
            F2((k-2)*3+2)=t*1000/T*l;
        end
    end
    
    
    b1=F1+M1*(1/(0.25*dt^2)*u1+1/(0.25*dt)*u_t1+(1/(2*0.25)-1)*u_tt1);
   
    
    b2=F2+M1*(1/(0.25*dt^2)*u2+1/(0.25*dt)*u_t2+(1/(2*0.25)-1)*u_tt2);
   
    R=1;

    k=0;

    while R > 1*10^(-12)

        
        for i=1:r_p
            
          sigma1(i)=0;
          
          for j=1:r_p
            if j<=i-1
              sigma1(i) = sigma1(i) + K_eff1(i,j)*u_p1(j);
            end
            if j>=i+1
              sigma1(i) = sigma1(i) + K_eff1(i,j)*u_p1(j);
            end
          end
            
          sigma2(i)=0;
          
          for j=1:r_p
            if j<=i-1
              sigma2(i) = sigma2(i) + K_eff1(i,j)*u_p2(j);
            end
            if j>=i+1
              sigma2(i) = sigma2(i) + K_eff1(i,j)*u_p2(j);
            end
          end
          
  
        end
        
        sigma1(end-2)=sigma1(end-2)+sigma2(1);
        sigma1(end-1)=sigma1(end-1)+sigma2(2);
        sigma1(end)=sigma1(end)+sigma2(3);
        
        sigma2(1)=sigma1(end-2);
        sigma2(2)=sigma1(end-1);
        sigma2(3)=sigma1(end);
        
        for i=1:r_p
            u_pk1(i)=1/K_eff1(i,i)*(b1(i)-sigma1(i));         
            u_pk2(i)=1/K_eff1(i,i)*(b2(i)-sigma2(i));
        end

          
        R=abs(sum(u_pk1-u_p1))+abs(sum(u_pk2-u_p2));

        u_p1=u_pk1;
        u_p2=u_pk2;
        k=k+1;
    end
    
    u_tt_p1=1/(0.25*dt^2)*(u_p1-u1)-1/(0.25*dt)*u_t1-(1/(2*0.25)-1)*u_tt1;  
    u_t_p1=u_t1+dt*0.5*u_tt1+dt*0.5*u_tt_p1;
    
    u1=u_p1;
    u_t1=u_t_p1;
    u_tt1=u_tt_p1;
    
    u_tt_p2=1/(0.25*dt^2)*(u_p2-u2)-1/(0.25*dt)*u_t2-(1/(2*0.25)-1)*u_tt2;  
    u_t_p2=u_t2+dt*0.5*u_tt2+dt*0.5*u_tt_p2;
    
    u2=u_p2;
    u_t2=u_t_p2;
    u_tt2=u_tt_p2;
 
end
    disp(u_p1);
    disp(u_p2);
    
   fprintf('Operation took %0.4f s.\n',toc);
   
   
%Explicit
%--------------------------

T=1; %s
N_t=8000;
dt=T/(N_t-1);

F=zeros(r,1);
u=zeros(r,1);
u_p=zeros(r,1);
u_m=zeros(r,1);

tic;

fprintf('Explicit\n------------------------------------------------------------\n');

t=0;
for n=1:N_t

    for k=2:N_e

        F((k-1)*3+1)=0;

        F((k-1)*3+3)=0;

        if k==(N_e/2+1) 
            F((k-1)*3+2)=t*1000/T*(l+1);
        else
            F((k-1)*3+2)=t*1000/T*l;
        end
    end
    

    
    for i=4:r-3
        u_p(i)=0;
        for j=4:r-3
            u_p(i)=u_p(i)-K(i,j)*u(j);
        end
    end
    
    
    for i=4:r-3
        u_p(i)=u_p(i)+F(i)+2/dt^2*M(i,i)*u(i)-1/dt^2*M(i,i)*u_m(i);
        u_p(i)=u_p(i)*dt^2/M(i,i);
    end
    

    u_m=u;
    u=u_p;
    
    t=t+dt;
end


disp(u);


fprintf('Operation took %0.4f s.\n',toc);  
   
   
%Explicit parallel
%--------------------------

tic;

fprintf('Explicit parallel\n------------------------------------------------------------\n');



r_p=3*(N_e/2+2);

u1=zeros(r_p,1);
u_p1=zeros(r_p,1);
u_m1=zeros(r_p,1);

F=zeros(r,1);


u2=zeros(r_p,1);
u_p2=zeros(r_p,1);
u_m2=zeros(r_p,1);


t=0;
for n=1:N_t
    
  
    
    for k=2:N_e

        F((k-1)*3+1)=0;

        F((k-1)*3+3)=0;

        if k==(N_e/2+1) 
            F((k-1)*3+2)=t*1000/T*(l+1);
        else
            F((k-1)*3+2)=t*1000/T*l;
        end
    end
    
   
    
    for i=4:(r_p-3)
        u_p1(i)=0;
        for j=4:(r_p-3) 
            if j>=(r_p-5) && i>=(r_p-5)
                u_p1(i)=u_p1(i)-K(i,j)*u1(j)/2;
            else
                u_p1(i)=u_p1(i)-K(i,j)*u1(j);
            end
        end
    end
    
    for i=4:(r_p-3)
        u_p2(i)=0;
        for j=4:(r_p-3)  
            if j<=6 && i<=6
                u_p2(i)=u_p2(i)-K(i,j)*u2(j)/2;
            else
                u_p2(i)=u_p2(i)-K(i,j)*u2(j);
            end
        end
    end
    
    u_p2(4)=u_p2(4)+u_p1(r_p-5);
    u_p2(5)=u_p2(5)+u_p1(r_p-4);
    u_p2(6)=u_p2(6)+u_p1(r_p-3);
    
    u_p1(r_p-5)=u_p2(4);
    u_p1(r_p-4)=u_p2(5);
    u_p1(r_p-3)=u_p2(6);
    

     
     for i=4:(r_p-3)
         
        u_p1(i)=u_p1(i)+F(i)+2/dt^2*M(i,i)*u1(i)-1/dt^2*M(i,i)*u_m1(i);
        u_p1(i)=u_p1(i)*dt^2/M(i,i);

        u_p2(i)=u_p2(i)+F(3*(N_e/2-1)+i)+2/dt^2*M(i,i)*u2(i)-1/dt^2*M(i,i)*u_m2(i);
        u_p2(i)=u_p2(i)*dt^2/M(i,i);
     end
    
     u_m1=u1;
     u1=u_p1;
     
     u_m2=u2;
     u2=u_p2;
     
      t=t+dt;
 
end

disp(u1);
disp(u2);
    
fprintf('Operation took %0.4f s.\n',toc);