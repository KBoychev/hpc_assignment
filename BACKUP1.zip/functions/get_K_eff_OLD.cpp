#include "functions.h"


void get_K_eff(int &r, double *M, double *K, double *K_eff, double &dt) {

	for(int i=0;i<r;i++){
		for(int j=0;j<r;j++){
			K_eff[i*r+j]=4.0/(dt*dt)*M[i*r+j]+K[i*r+j];
		}
	}

}