

#ifndef _funcitons_h
#define _funcitons_h

	#include <iostream>
	#include <iomanip>
	#include <string>

	#include <Accelerate/Accelerate.h>
	
	void set_M_e(int&,int&,double*,double&,double&,double&);

	void set_K_e(int&,int&,double*,double&,double&,double&,double&);

	void get_M(int&,int&,double*,int&,double*,int&);

	void get_K(int&,int&,double*,int&,double*, int&);

	void get_K_eff(int&, double*, double*, double*, double&); 

	void get_F(int&, double*, int&, double&, double&);

	void inv(int&,double*);

	void disp(int,int,double*,std::string);

	void get_u_p_explicit(int&, int&, double*, double*, double*, double*, double*, double*, double&, int&, int&);

	void get_u_p_implicit(int&, int&,double*,double*,double*,double*,double*,double*,double*,double*,double*,double&,int&,int&);

#endif
