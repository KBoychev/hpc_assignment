clear all;
close all;
clc;

load matlab.mat;

r=21;

F=zeros(r,1);
L=10;
N_e=6;
l=L/N_e;

T=1;
N_t=1000;
dt=T/(N_t-1);



%Invert entire
%--------------------------

fprintf('Ivert entire\n------------------------------------------------------------\n');


t=0;
for n=1:N_t

    for k=2:N_e

        F((k-1)*3+1)=0;

        F((k-1)*3+3)=0;

        if k==(N_e/2+1) 
            F((k-1)*3+2)=t*1000/T*(l+1);
        else
            F((k-1)*3+2)=t*1000/T*l;
        end
    end
   
    u=K_eff_inv*F;

    t=t+dt;
end

disp(t);
disp(u);
 
 

%Jacobi entire
%--------------------------

fprintf('Jacobi entire\n------------------------------------------------------------\n');

t=0;
for n=1:100

    for k=2:N_e

        F((k-1)*3+1)=0;

        F((k-1)*3+3)=0;

        if k==(N_e/2+1) 
            F((k-1)*3+2)=t*1000/T*(l+1);
        else
            F((k-1)*3+2)=t*1000/T*l;
        end
    end
    
    u=zeros(21,1);
    uk=zeros(21,1);

    R=1;

    k=0;

    while R > 1*10^(-10)

        for i=1:21
          sigma=0;
          for j=1:21
            if j~=i
              sigma = sigma + K_eff(i,j)*u(j);
            end
          end

          uk(i)=1/K_eff(i,i)*(F(i)-sigma);
        end

        R=abs(sum(uk-u));

        u=uk;
        k=k+1;
    end
    
    t=t+dt;
end

disp(t);
disp(u);

%Invert inner
%--------------------------

fprintf('Inner\n------------------------------------------------------------\n');

K_eff_inner=K_eff(4:18,4:18);
K_eff_inv_inner=inv(K_eff_inner);
F_inner=F(4:18);

u=K_eff_inv_inner*F_inner;

disp(u);

%Jacobi inner
%--------------------------

fprintf('Jacobi inner\n------------------------------------------------------------\n');

u=zeros(15,1);
uk=zeros(15,1);

R=1;

k=0;

while R > 1*10^(-10)

    for i=1:15
      sigma=0;
      for j=1:15
        if j~=i
          sigma = sigma + K_eff_inner(i,j)*u(j);
        end
      end

      uk(i)=1/K_eff_inner(i,i)*(F_inner(i)-sigma);
    end
    
    R=abs(sum(uk-u));

    u=uk;
    k=k+1;
end
    
disp(k);
disp(u);

