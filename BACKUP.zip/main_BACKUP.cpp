

#include <iostream>
#include <iomanip>
#include <string>

#include "mpi.h"
#include "functions.h"


int main(int argc, char *argv[]) {


	//// Set MPI variables and initialise MPI (TODO)
	//-----------------------------------------------------

	int MPI_NP;
	int MPI_P_ID;
	int MPI_status;


	MPI_status = MPI_Init(&argc, &argv);

	MPI_status = MPI_Comm_size(MPI_COMM_WORLD,&MPI_NP);

 	MPI_status = MPI_Comm_rank(MPI_COMM_WORLD,&MPI_P_ID);


	int N_e = 0;
	double L = 0;	
	double A = 0;
	double I = 0;
	double E = 0;
	double rho = 0;
	double T = 0;
	int N_t = 0;
	double t=0;
	int eq;
	int sch;

	for (int i=1; i<argc; i++){

		if(std::strcmp(argv[i],"-L")==0){
			L=std::atof(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-N_e")==0){
			N_e=std::stoi(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-A")==0){
			A=std::stod(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-I")==0){
			I=std::stod(argv[i+1]);	
		}
		if(std::strcmp(argv[i],"-E")==0){
			E=std::stod(argv[i+1]);	
		}
		if(std::strcmp(argv[i],"-T")==0){
			T=std::stod(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-N_t")==0){
			N_t=std::stoi(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-rho")==0){
			rho=std::stod(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-eq")==0){
			eq=std::stoi(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-sch")==0){
			sch=std::stoi(argv[i+1]);
		}
	}

	double l = L / N_e; //element length
	double dt = T / ( N_t - 1); //timestep
	
	//// Element mass,stiffness, force matrices 
	//	 and vectors
	//--------------------------------------------------------

	int r_e = 6; //rows 

	double *M_e = new double[r_e*r_e](); // element mass matrix
	double *K_e = new double[r_e*r_e](); // element stiffness matrix


	//// Global mass, stiffness, load, displacement matrices 
	//	 and vectors
	//--------------------------------------------------------
	int r = 3 * (N_e + 1); 

	double *M = new double[r*r](); // global mass matrix
	double *K = new double[r*r](); // global stiffness matrix
	double *F = new double[r](); //global force vector
	double *u = new double[r](); // u at timelayer n
	double *u_p = new double[r](); // u at timelayer n+1
	
	//// Set and display the  element mass matrix [M_e]
	//--------------------------------------------------------

	set_M_e(r_e,r_e, M_e, rho, A, l);

	if(MPI_P_ID==0){

		disp(r_e,r_e,M_e,"M_e");
	}

	//// Set and display the element stiffness matrix [K_e]
	//--------------------------------------------------------

	set_K_e(r_e, r_e,K_e, E, A, I, l);

	if(MPI_P_ID==0){

		disp(r_e, r_e, K_e, "K_e");

	}

	//// Get and display global mass matrix [M]
	//--------------------------------------------------------

	get_M(r, r, M, r_e, M_e, N_e);

	if(MPI_P_ID==0){

		disp(r,r,M,"M");

	}

	//// Get global stiffness matrix [K], set boundary conditions and display
	//--------------------------------------------------------

	get_K(r,r, K, r_e, K_e, N_e);


	for (int i = 0; i<r; i++) {
		for (int j = 0; j<r; j++) {
			if(i==0||i==1||i==2||i==r-3||i==r-2||i==r-1){
				if(j==i){
					K[i*r+j]=1;
				}else{
					K[i*r+j]=0;				
				}
			}
		}
	}

	if(MPI_P_ID==0){

		disp(r,r, K, "K");
	
	}


	//// Solve the static problem [K]{u}={F}. 
	//--------------------------------------------------------

	if(eq==0){

		if(MPI_P_ID==0){
			
			std::cout<<std::endl;
	 		std::cout<<"Solving [K]{u}={F}"<<std::endl;

	 	}

		//Get and display force vector {F} at time t=1s.
		//------------------------------
		
		t=1;

		get_F(r,F,N_e,l,t);

		disp(r,1,F,"F");

	 	//Invert the stiffness matrix [K]
		//------------------------------

		inv(r,K); 


		//Get and display u 
		//------------------------------


		for(int i=0;i<r;i++){
			u[i]=0;
			for(int j=0;j<r;j++){
				u[i]=u[i]+K[i*r+j]*F[j];
			}
		}


		std::cout<<std::endl;
		std::cout<<"Done!"<<std::endl;
	 	std::cout<<std::endl;

		disp(r,1,u,"u");

	}

		//// Solve the dynamic problem [M]d2{u}/dt2+[K]{u}={F}. 
		//--------------------------------------------------------

		if(eq==1){


			std::cout<<"Solving [M]d2{u}/dt2+[K]{u}={F}"<<std::endl;
			std::cout<<std::endl;
			

			//// Solution is performed with explicit method.
			//--------------------------------------------------------

			if(sch==0){


				double *u_m = new double[r]();  // u at timelayer n-1

				//Loop for N_t timesteps
				//-------------------------------

				t=0;

				for(int n_t=0;n_t<(N_t+1);n_t++){

					//Get force vector {F} at time t
					//------------------------------

					get_F(r,F,N_e,l,t);

					//Get u at timelayer n+1
					//-------------------------------

					for(int i=3;i<(r-3);i++){

						u_p[i]=0;

						for(int j=3;j<(r-3);j++){

							u_p[i]=u_p[i]-(K[i*r+j]-2.0/(dt*dt)*M[i*r+j])*u[j]-1.0/(dt*dt)*M[i*r+j]*u_m[j];

						}

						u_p[i]=u_p[i]+F[i];

						u_p[i]=u_p[i]*dt*dt*1.0/M[i*r+i];
					}

					// Overwrite u at timelayer n-1 with u at timelayer n
					// and u at timelayer n with u at timelayer n+1
					//-------------------------------

					for(int i=3;i<(r-3);i++){
						u_m[i]=u[i];
						u[i]=u_p[i];
					}

					t=t+dt;

				}

			}

			//// Solution is performed with implicit method.
			//--------------------------------------------------------
			if(sch==1){

				double *u_tt = new double[r](); // second time derivative of u at timelayer n
				double *u_tt_p = new double[r](); // second time derivative of u at timelayer n+1
				double *u_t = new double[r](); // first time derivative of u at timelayer n
				double *u_t_p = new double[r](); // first time derivative of u at timelayer n+1
				double *K_eff = new double[r*r](); // effective stiffness matrix


				double *tmp = new double[r]();


				//Get and invert the effective stiffness matrix [K_eff]
				//-------------------------------

				for(int i=0;i<r;i++){
					for(int j=0;j<r;j++){
						K_eff[i*r+j]=4.0/(dt*dt)*M[i*r+j]+K[i*r+j];
					}
				}

				disp(r,r,K_eff,"K_eff");

				inv(r,K_eff);


				//Loop for N_t timesteps
				//-------------------------------

				t=0;

				for(int n_t=0;n_t<(N_t+1);n_t++){


					t=t+dt;

					//Get force vector {F} at timelayer n+1
					//------------------------------

					get_F(r,F,N_e,l,t);


					//Get u, u_tt and u_t at timelayer n+1
					//-------------------------------


					for(int i=3;i<(r-3);i++){

						tmp[i]=0;

						for(int j=3;j<(r-3);j++){

							tmp[i]=tmp[i]+M[i*r+j]*(1.0/(0.25*dt*dt)*u[j]+1.0/(0.25*dt)*u_t[j]+(1.0/(0.25*2.0)-1.0)*u_tt[j]);

						}

						tmp[i]=tmp[i]+F[i];
					}


					for(int i=3;i<(r-3);i++){

						u_p[i]=0;

						for(int j=3;j<(r-3);j++){
							u_p[i]=u_p[i]+K_eff[i*r+j]*tmp[j];

						}

						u_tt_p[i]=1.0/(0.25*dt*dt)*(u_p[i]-u[i])-1.0/(0.25*dt)*u_t[i]-(1.0/(0.25*2.0)-1.0)*u_tt[i];

						u_t_p[i]=u_t[i]+dt*0.5*u_tt[i]+dt*0.5*u_tt_p[i];
					}

					// Overwrite u at timelayer n with u at timelayer n+1,
					// u_tt at at timelayer n with u_tt at timelayer n+1,
					// and u_t at timelayer n with u_t at timelayer n+1
					//-------------------------------

					for(int i=3;i<(r-3);i++){
						u[i]=u_p[i];				
						u_tt[i]=u_tt_p[i];
						u_t[i]=u_t_p[i];
					}

					

				}

			}
		

			std::cout<<std::endl;
			std::cout<<"Done!"<<std::endl;
		 	std::cout<<std::endl;

			disp(r,1,u,"u");

		}



	return 0;
}
