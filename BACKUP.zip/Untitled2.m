clear all;
close all;
clc;



N_e=6;
L=10.0; %m
l=L/N_e; %m
A=0.1*0.12; %m2
I=(0.1*0.12^3)/12; %m4
E=2.1*10^11; %Pa
rho=7850; %kg/m3
T=1; %s

qy=1000; %N/m
Fy=1000; %N

r_e=6;
c_e=6;

K_e=zeros(r_e,c_e);
M_e=zeros(r_e,c_e);
F_e=zeros(r_e,1);

%% Set M_e
% ------------------------------------------------------------

for i=1:r_e
    for j=i:c_e
        
        M_e(i,j)=0;
        
        if i==j
            
            if i==3 || i==6
                M_e(i,j)=rho*A*l^3*1/24;
            else 
                M_e(i,j)=rho*A*l*1/2;
            end  
            
        end
    end
end

fprintf('%ix%i [M_e]=\n',r_e,c_e);
disp(M_e);
    
 %% Set K_e
 % ------------------------------------------------------------
    
for i=1:r_e
    for j=i:c_e
        
        K_e(i,j)=0;
        
        if i==j
            
            if i==1 || i==4
                K_e(i,j)=(A*E)/l;
            end
            
            if i==2 || i==5
                K_e(i,j)=(12*E*I)/l^3;
            end
            
            if i==3 || i==6
                K_e(i,j)=(4*E*I)/l;
            end
   
        end
        
        if i==1 && j==4
            K_e(i,j)=-(A*E)/l;
        end
        
        if i==2 && j==3
            K_e(i,j)=(6*E*I)/l^2;
        end
        
        if i==2 && j==5
            K_e(i,j)=-(12*E*I)/l^3;
        end
        
        if i==2 && j==6
            K_e(i,j)=(6*E*I)/l^2;
        end
        
        if i==3 && j==5
            K_e(i,j)=-(6*E*I)/l^2;
        end
        
        if i==3 && j==6
            K_e(i,j)=(2*E*I)/l;
        end
        
         if i==5 && j==6
            K_e(i,j)=-(6*E*I)/l^2;
        end
        
        if j~=i
            K_e(j,i)=K_e(i,j);
        end
        
    end
end

fprintf('%ix%i [K_e]=\n',r_e,c_e);
disp(K_e);

%% Set F_e
% ------------------------------------------------------------
    
F_e(2)=qy*l/2;
F_e(3)=(qy*l^2)/12;
F_e(5)=qy*l/2;
F_e(6)=-(qy*l^2)/12;

fprintf('%ix%i {F_e}=\n',r_e,1);
disp(F_e);

r=3*(N_e+1);
c=3*(N_e+1);

K=zeros(r,c);
M=zeros(r,c);
F=zeros(r,1);
u=zeros(r,1);

%% Assemble M
% ------------------------------------------------------------

for k=1:N_e

        M((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)))=M_e+M((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)));
 
end

fprintf('%ix%i [M]=\n',r,c);
disp(M);

%% Assemble K
% ------------------------------------------------------------

for k=1:N_e

    K((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)))=K_e+K((3*k-2):(3*(k+1)),(3*k-2):(3*(k+1)));
  
end



% No displacements or rotation
% at the first and last node
%--------------
% K(1,:)=0; 
% K(2,:)=0;
% K(3,:)=0;
% K(r-2,:)=0;
% K(r-1,:)=0;
% K(r,:)=0;
% 
% K(1,1)=1;
% K(2,2)=1;
% K(3,3)=1;
% K(r-2,r-2)=1;
% K(r-1,r-1)=1;
% K(r,r)=1;

fprintf('%ix%i [K]=\n',r,c);
disp(K);


%% Assemble F
% ------------------------------------------------------------

for k=1:N_e
    
    if k==1 
        F((3*k-2):(3*(k+1)))=F_e;
    else
        F((3*k-2):(3*(k+1)))=F_e+F((3*k-2):(3*(k+1)));
    end
end

F(3*(N_e/2+1)-1)=F(3*(N_e/2+1)-1)+Fy;

% No forces or moments at
% at the first and last node
%--------------
F(1)=0;
F(2)=0; 
F(3)=0; 
F(r-2)=0;
F(r-1)=0; 
F(r)=0;

fprintf('%ix%i {F}=\n',r,1);
disp(F);

%% Slove [K_e]{u}={F}
% ------------------------------------------------------------

u=inv(K)*F;

fprintf('%ix%i {u}=\n',r,1);

disp(u);



for k=1:(N_e/2+1)
    uy_s(k)=u(3*k-1);
end



N_t=8000; %-
dt=T/(N_t-1); %s

disp(dt);


%% Solve [M]{u_ddot}+[K}{u}={F}
% ------------------------------------------------------------

fprintf('Dynamic explicit\n------------------------------------------------------------\n');

M_p=M_e(1:3,1:3)+M_e(4:6,4:6);
K_p=K_e(1:3,1:3)+K_e(4:6,4:6);
K_pp=K_e(1:3,4:6);
K_pm=K_e(4:6,1:3);
F_p=zeros(3,1);
u_p=zeros(r,1);
u_pp=zeros(r,1);
u_pm=zeros(r,1);

t=0;

for n_t=1:N_t
    
    for n_e=2:N_e
        
       if n_e==(N_e/2+1)
           F_p(2)=t*1000/T*(l+1);
       else
           F_p(2)=t*1000/T*l;
       end
       

       
       for i=1:3
           u_pp((n_e-1)*3+i)=0;
           for j=1:3
               u_pp((n_e-1)*3+i)=u_pp((n_e-1)*3+i)-K_pm(i,j)*u_p((n_e-2)*3+j)-K_p(i,j)*u_p((n_e-1)*3+j)-K_pp(i,j)*u_p(n_e*3+j);
           end
           
           u_pp((n_e-1)*3+i)=u_pp((n_e-1)*3+i)+F_p(i)+2/dt^2*M_p(i,i)*u_p((n_e-1)*3+i)-1/dt^2*M_p(i,i)*u_pm((n_e-1)*3+i);
           u_pp((n_e-1)*3+i)=dt^2/M_p(i,i)*u_pp((n_e-1)*3+i);
       end
       
       
        
    end
   
    
    
    
    u_pm=u_p;
    u_p=u_pp;
  
    t=t+dt;

end

disp(u_p);

for k=1:(N_e/2+1)
    uy_de(k)=u_p(3*k-1);
end


fprintf('Dynamic explicit parallel\n------------------------------------------------------------\n');

r_p=N_e/2*3;

M_p=M(4:3*(N_e/2+1),1:3*(N_e/2+2));
K_p=K(4:3*(N_e/2+1),1:3*(N_e/2+2));
M_p_inv=inv(M(4:3*(N_e/2+1),4:3*(N_e/2+1)));

disp(M_p);
disp(K_p);


disp(size(M_p));
disp(size(K_p));

F_p=zeros(r_p,1);

u_p1=zeros(r_p+6,1);
u_pp1=zeros(r_p+6,1);
u_pm1=zeros(r_p+6,1);

u_p2=zeros(r_p+6,1);
u_pp2=zeros(r_p+6,1);
u_pm2=zeros(r_p+6,1);




t=0;

for n_t=1:N_t
    

    for k=2:(N_e/2+1)
        
        F_p((k-2)*3+1)=0;
        
        F_p((k-2)*3+3)=0;

        if k==(N_e/2+1)
            F_p((k-2)*3+2)=t*1000/T*(l+1);
        else
            F_p((k-2)*3+2)=t*1000/T*l;
        end
    end
    

    u_pp1(4:3*(N_e/2+1))=dt^2*M_p_inv*(F_p-(K_p-2/dt^2*M_p)*u_p1-1/dt^2*M_p*u_pm1);
    
    
     
    u_pp2(1)=u_pp1((N_e/2)*3-2);
    u_pp2(2)=u_pp1((N_e/2)*3-1);
    u_pp2(3)=u_pp1((N_e/2)*3-0);
    

        
    
    for k=2:(N_e/2+1)
        
        F_p((k-2)*3+1)=0;
        
        F_p((k-2)*3+3)=0;

        if k==2
            F_p((k-2)*3+2)=t*1000/T*(l+1);
        else
            F_p((k-2)*3+2)=t*1000/T*l;
        end
    end
    
    
    
    u_pp2(4:3*(N_e/2+1))=dt^2*M_p_inv*(F_p-(K_p-2/dt^2*M_p)*u_p2-1/dt^2*M_p*u_pm2);
   

    u_pp1(end-2)=u_pp2(7);
    u_pp1(end-1)=u_pp2(8);
    u_pp1(end)=u_pp2(9);
    
   
    u_pm1=u_p1;
    u_p1=u_pp1;
    
    u_pm2=u_p2;
    u_p2=u_pp2;
    
    t=t+dt;
end


disp(u_p1);
disp(u_p2);

for k=1:(N_e/2+1)
   uy_dep(k)=u_p1(3*k-1);
end


N_t=1000; %-
dt=T/(N_t-1); %s
disp(dt);

fprintf('Dynamic implicit\n------------------------------------------------------------\n');


F=zeros(r,1);

u_p=zeros(r,1);
u_pp=zeros(r,1);
u_pt=zeros(r,1);
u_ptt=zeros(r,1);
u_ptp=zeros(r,1);
u_pttp=zeros(r,1);


K_eff=1/(0.25*dt^2)*M+K;

K_eff_inv=inv(K_eff);


t=0;

for n_t=1:1000

    for k=2:N_e
        
        F((k-1)*3+1)=0;
        
        F((k-1)*3+3)=0;

        if k==(N_e/2+1) 
            F((k-1)*3+2)=(t+dt)*1000/T*(l+1);
        else
            F((k-1)*3+2)=(t+dt)*1000/T*l;
        end
    end
    
    u_pp=K_eff_inv*(F+M*(1/(0.25*dt^2)*u_p+1/(0.25*dt)*u_pt+(1/(0.25*2)-1)*u_ptt));

    u_pttp=1/(0.25*dt^2)*(u_pp-u_p)-1/(0.25*dt)*u_pt-(1/(0.25*2)-1)*u_ptt;
    u_ptp=u_pt+dt*0.5*u_ptt+dt*0.5*u_pttp;
    
    u_p=u_pp;
    u_ptt=u_pttp;
    u_pt=u_ptp;
    
    
    t=t+dt;
end

disp(u_p);


for k=1:(N_e/2+1)
    uy_di(k)=u_p(3*k-1);
end


N_t=1000; %-
dt=T/(N_t-1); %s
disp(dt);



fprintf('Dynamic implicit parallel\n------------------------------------------------------------\n');

r_p=N_e/2*3;


K_eff=1/(0.25*dt^2)*M+K;

K_eff_inv=inv(K_eff);


M_p=M(4:(3*(N_e/2+1)+6),4:(3*(N_e/2+1)+6));
K_peff_inv1=K_eff_inv(4:3*(N_e/2+1),1:3*(N_e/2+2));
K_peff_inv2=K_eff_inv((end-3*(N_e/2+2)+4):end-3,(end-3*(N_e/2+2)+1):end);


F_p=zeros(r_p+6,1);
y=zeros(r_p,1);
b=zeros(r_p,1);


u_p1=zeros(r_p+6,1);
u_pp1=zeros(r_p+6,1);
u_pt1=zeros(r_p+6,1);
u_ptt1=zeros(r_p+6,1);
u_ptp1=zeros(r_p+6,1);
u_pttp1=zeros(r_p+6,1);


u_p2=zeros(r_p+6,1);
u_pp2=zeros(r_p+6,1);
u_pt2=zeros(r_p+6,1);
u_ptt2=zeros(r_p+6,1);
u_ptp2=zeros(r_p+6,1);
u_pttp2=zeros(r_p+6,1);

disp(size(F_p));

t=0;

for n_t=1:1000
    
   F_p=zeros(r_p+6,1);
    
    for k=2:(N_e/2+2)
        
        F_p((k-1)*3+1)=0;
        
        F_p((k-1)*3+3)=0;

        if k==(N_e/2+1)
            F_p((k-1)*3+2)=(t+dt)*1000/T*(l+1);
        else
            F_p((k-1)*3+2)=(t+dt)*1000/T*l;
        end
    end
    
    
    u_pp1(4:(r_p+3))=K_peff_inv1*(F_p+M_p*(1/(0.25*dt^2)*u_p1+1/(0.25*dt)*u_pt1+(1/(0.25*2)-1)*u_ptt1));
    u_pttp1=1/(0.25*dt^2)*(u_pp1-u_p1)-1/(0.25*dt)*u_pt1-(1/(0.25*2)-1)*u_ptt1;
    u_ptp1=u_pt1+dt*0.5*u_ptt1+dt*0.5*u_pttp1;
    
    u_pp2(1)=u_pp1((N_e/2)*3-2);
    u_pp2(2)=u_pp1((N_e/2)*3-1);
    u_pp2(3)=u_pp1((N_e/2)*3-0);
    
    u_pttp2(1)=u_pttp1((N_e/2)*3-2);
    u_pttp2(2)=u_pttp1((N_e/2)*3-1);
    u_pttp2(3)=u_pttp1((N_e/2)*3-0);
    
    u_ptp2(1)=u_ptp1((N_e/2)*3-2);
    u_ptp2(2)=u_ptp1((N_e/2)*3-1);
    u_ptp2(3)=u_ptp1((N_e/2)*3-0);
    
  
    
    F_p=zeros(r_p+6,1);
    
    for k=1:(N_e/2+1)
        
        F_p((k-1)*3+1)=0;
        
        F_p((k-1)*3+3)=0;

        if k==2
            F_p((k-1)*3+2)=(t+dt)*1000/T*(l+1);
        else
            F_p((k-1)*3+2)=(t+dt)*1000/T*l;
        end
    end
    
 
    
   
    u_pp2(4:(r_p+3))=K_peff_inv2*(F_p+M_p*(1/(0.25*dt^2)*u_p2+1/(0.25*dt)*u_pt2+(1/(0.25*2)-1)*u_ptt2));
    u_pttp2=1/(0.25*dt^2)*(u_pp2-u_p2)-1/(0.25*dt)*u_pt2-(1/(0.25*2)-1)*u_ptt2;
    u_ptp2=u_pt2+dt*0.5*u_ptt2+dt*0.5*u_pttp2;

    u_pp1(end-2)=u_pp2(7);
    u_pp1(end-1)=u_pp2(8);
    u_pp1(end)=u_pp2(9);
    
    u_pttp1(end-2)=u_pttp2(7);
    u_pttp1(end-1)=u_pttp2(8);
    u_pttp1(end)=u_pttp2(9);
    
    u_ptp1(end-2)=u_ptp2(7);
    u_ptp1(end-1)=u_ptp2(8);
    u_ptp1(end)=u_ptp2(9);
   
    u_p1=u_pp1;
    u_pt1=u_ptp1;
    u_ptt1=u_pttp1;
    
    u_p2=u_pp2;
    u_pt2=u_ptp2;
    u_ptt2=u_pttp2;
  
  
    t=t+dt;
end


disp(u_p1);
disp(u_p2);


    
for k=1:(N_e/2+1)
     uy_dip(k)=u_p1(3*k-1);
end

x=0:l:L/2;

x_a=0:0.01:L/2;
uy_a=(Fy*x_a.^2)/(48*E*I).*(3*L-4*x_a) + (qy*x_a.^2)/(24*E*I).*(L-x_a).^2;


figure(1);
hold on;
plot(x,uy_s,'DisplayName','Static','Marker','+');
plot(x,uy_de,'DisplayName','Dynamic explicit','Marker','o');
plot(x,uy_dep,'DisplayName','Dynamic explicit parallel','Marker','s');
plot(x,uy_di,'DisplayName','Dynamic implicit','Marker','x');
plot(x,uy_dip,'DisplayName','Dynamic implicit parallel','Marker','*');
plot(x_a,uy_a,'DisplayName','Static analytical');
grid on;
legend('show');