#include "functions.h"


void get_F(int &r, double *F, int &N_e, double &l, double &t) {


	for(int n=1;n<N_e;n++){

		F[3*n+0]=0;

		

		if(n==N_e/2){			
			F[3*n+1]=t*1000.0*(l+1);
		}else{
			F[3*n+1]=t*1000.0*l;
		}


		F[3*n+2]=0;

	}

}