#include "functions.h"


void get_u_p_implicit(int &r, int &r_p, double *u_p, double *u, double *u_t, double *u_t_p, double *u_tt, double *u_tt_p, double *M, double *K_eff, double *F, double &dt, int &N_e, int &MPI_P_ID){


	//K_eff is different for the different processes
	//need to fix implicit shit

	//JACOBI ITERATION MAYBE?

	double *tmp=new double[r_p]();


	for(int i=0;i<r_p;i++){

		tmp[i]=0;

		for(int j=0;j<r_p;j++){

			tmp[i]=tmp[i]+M[i*r+j]*(1.0/(0.25*dt*dt)*u[j]+1.0/(0.25*dt)*u_t[j]+(1.0/(0.25*2.0)-1.0)*u_tt[j]);

		}

		if(MPI_P_ID==1){
			tmp[i]=tmp[i]+F[3*(N_e/2-1)+i]; //right half of global force vector
		}else{
			tmp[i]=tmp[i]+F[i]; //left half of global force vector
		}
		
	}

	//update only inner nodes
	for(int i=3;i<(r_p-3);i++){

		u_p[i]=0;

		for(int j=0;j<r_p;j++){
			if(MPI_P_ID==1){
				u_p[i]=u_p[i]+K_eff[(i+6)*r+(j+6)]*tmp[j];
			}else{
				u_p[i]=u_p[i]+K_eff[i*r+j]*tmp[j];
			}
		}

		u_tt_p[i]=1.0/(0.25*dt*dt)*(u_p[i]-u[i])-1.0/(0.25*dt)*u_t[i]-(1.0/(0.25*2.0)-1.0)*u_tt[i];

		u_t_p[i]=u_t[i]+dt*0.5*u_tt[i]+dt*0.5*u_tt_p[i];
	}

	delete[] tmp;


}
