#include "functions.h"


void get_u_p_explicit(int &r, int &r_p, double *u_p, double *u, double *u_m, double *M, double *K, double *F, double &dt, int &N_e, int &MPI_P_ID){

	for(int i=3;i<(r_p-3);i++){

		u_p[i]=0;

		for(int j=0;j<r_p;j++){

			u_p[i]=u_p[i]-(K[i*r+j]-2.0/(dt*dt)*M[i*r+j])*u[j]-1.0/(dt*dt)*M[i*r+j]*u_m[j];

		}

		if(MPI_P_ID==1){
			u_p[i]=u_p[i]+F[3*(N_e/2-1)+i]; //right half of global force vector
		}else{
			u_p[i]=u_p[i]+F[i]; //left half of global force vector
		}

		u_p[i]=u_p[i]*dt*dt*1.0/M[i*r+i];

	}
}
