for n_t=1:1
    
    fprintf('Iteration:%i, t:%0.6f\n------------------------------------------------------------\n',n_t,t);


    for n_e=2:2:N_e
        
       
       
       
       for i=1:9
           
           u_ptmp((n_e-2)*3+i)=0;
           
           for j=1:9
              u_ptmp((n_e-2)*3+i)=u_ptmp((n_e-2)*3+i)+M_p(i,j)*(1/(0.25*dt^2)*u_p((n_e-2)*3+j)+1/(0.25*dt)*u_pt((n_e-2)*3+j)+(1/(2*0.25)-1)*u_ptt((n_e-2)*3+j));
           end
           
           if i <= 3
               u_ptmp((n_e-2)*3+i)=u_ptmp((n_e-2)*3+i)+F_p(i);
           end
           
           if i >= 4 && i<=6  
               
               if n_e==(N_e/2+1)
                   F_p(2)=t*1000/T*(l+1);
               else
                   F_p(2)=t*1000/T*l;
               end
       
               u_ptmp((n_e-2)*3+i)=u_ptmp((n_e-2)*3+i)+F_p(i-3);
           end
          
           if i>=7 && i <= 9       
               u_ptmp((n_e-2)*3+i)=u_ptmp((n_e-2)*3+i)+F_p(i-6);
           end

       end
        
        for i=1:9
           
           u_pp((n_e-2)*3+i)=0;
           
           for j=1:9
              u_pp((n_e-2)*3+i)=u_pp((n_e-2)*3+i)+K_peff_inv(i,j)*u_ptmp((n_e-2)*3+j);
           end
           
            u_pttp((n_e-2)*3+i)=1/(0.25*dt^2)*u_pp((n_e-2)*3+i)-u_p((n_e-2)*3+i)-1/(0.25*dt)*u_pt((n_e-2)*3+i) -(1/(2*0.25)-1)*u_ptt((n_e-2)*3+i);
            
            u_ptp((n_e-2)*3+i)=u_pt((n_e-2)*3+i)+dt*0.5*u_ptt((n_e-2)*3+i)+dt*0.5*u_pttp((n_e-2)*3+i);

        
        end
        
    end
    
    u_pm=u_p;
    u_p=u_pp;
    u_pt=u_ptp;
    u_ptt=u_pttp;
  
    t=t+dt;

end

disp(u_p);