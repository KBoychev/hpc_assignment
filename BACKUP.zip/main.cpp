

#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>

#include "mpi.h"
#include "functions.h"


int main(int argc, char *argv[]) {


	//// Set MPI variables and initialise MPI (TODO)
	//-----------------------------------------------------

	int MPI_N_P;
	int MPI_P_ID;
	int MPI_status;


	MPI_status = MPI_Init(&argc, &argv);

	MPI_status = MPI_Comm_size(MPI_COMM_WORLD,&MPI_N_P);

 	MPI_status = MPI_Comm_rank(MPI_COMM_WORLD,&MPI_P_ID);


	int N_e = 0;
	double L = 0;	
	double A = 0;
	double I = 0;
	double E = 0;
	double rho = 0;
	double T = 0;
	int N_t = 0;
	double t=0;
	int eq;
	int sch;

	for (int i=1; i<argc; i++){

		if(std::strcmp(argv[i],"-L")==0){
			L=std::atof(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-N_e")==0){
			N_e=std::stoi(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-A")==0){
			A=std::stod(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-I")==0){
			I=std::stod(argv[i+1]);	
		}
		if(std::strcmp(argv[i],"-E")==0){
			E=std::stod(argv[i+1]);	
		}
		if(std::strcmp(argv[i],"-T")==0){
			T=std::stod(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-N_t")==0){
			N_t=std::stoi(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-rho")==0){
			rho=std::stod(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-eq")==0){
			eq=std::stoi(argv[i+1]);
		}
		if(std::strcmp(argv[i],"-sch")==0){
			sch=std::stoi(argv[i+1]);
		}
	}

	double l = L / N_e; //element length
	double dt = T / ( N_t - 1); //timestep
	
	//// Element mass and stiffness matrices 
	//	 and vectors for each process
	//--------------------------------------------------------

	int r_e = 6; //rows of element mass and stiffness matrices

	double *M_e = new double[r_e*r_e](); // element mass matrix [M_e]
	double *K_e = new double[r_e*r_e](); // element stiffness matrix [K_e]

	//// Global mass [M], stiffness [K], and force {F} matrices 
	//	 and vectors for each process
	//--------------------------------------------------------
	
	int r = 3*(N_e+1); //rows of global mass and stiffness elements

	double *M = new double[r*r](); // global mass matrix [M]
	double *K = new double[r*r](); // global stiffness matrix [K]
	double *F = new double[r](); //global force vector {F}
	
	
	//// Set and display the  element mass matrix [M_e]
	// for each process
	//--------------------------------------------------------

	set_M_e(r_e,r_e, M_e, rho, A, l);

	if(MPI_P_ID==0){

		disp(r_e,r_e,M_e,"M_e");
	}

	//// Set and display the element stiffness matrix [K_e]
	// for each process
	//--------------------------------------------------------

	set_K_e(r_e, r_e,K_e, E, A, I, l);

	if(MPI_P_ID==0){

		disp(r_e, r_e, K_e, "K_e");

	}

	//// Get and display global mass matrix [M]
	// for each process
	//--------------------------------------------------------

	get_M(r, r, M, r_e, M_e, N_e);

	if(MPI_P_ID==0){

		disp(r,r,M,"M");

	}

	//// Get global stiffness matrix [K] for each process
	//--------------------------------------------------------

	get_K(r,r, K, r_e, K_e, N_e);

	if(MPI_P_ID==0){
		disp(r,r, K, "K");
	}

	//// Solve the static problem [K]{u}={F} on one process. 
	//--------------------------------------------------------

	if(eq==0 && MPI_N_P==1){	
			
		std::cout<<std::endl;
	 	std::cout<<"Solving [K]{u}={F}"<<std::endl;

	 	// Global displacement vector {u}
		//------------------------------

	 	double *u = new double[r](); 

		// Get and display the global force vector {F} at time t=1s.
		//------------------------------
		
		t=1;

		get_F(r,F,N_e,l,t);

		disp(r,1,F,"F");

	 	// Invert the global stiffness matrix [K]
		//------------------------------
		// JACOBI ITERATION MAYBE?
		inv(r,K); 

		// Get, display, and store u 
		//------------------------------

		std::ofstream results_file;
		results_file.open("results.csv");

		for(int i=0;i<r;i++){
			u[i]=0;
			for(int j=0;j<r;j++){
				u[i]=u[i]+K[i*r+j]*F[j];
			}
			if(results_file.good()){
				results_file<<u[i]<<"\n";
			}
		}
		results_file.close();

 		std::cout<<std::endl<<"Done!"<<std::endl;
		disp(r,1,u,"u");

	}else{
		MPI_Finalize();
		return 1;
	}

	//// Solve the dynamic problem [M]d2{u}/dt2+[K]{u}={F} on
	// 	 one or two processes.
	//--------------------------------------------------------

	if(eq==1 && MPI_N_P<=2){

		int r_p = 3*(N_e/MPI_N_P+MPI_N_P); //get size of {u} depending on number of processes

		double *u_buff = new double[3](); //buffer of {u} to keep values of displacement for one node

		double *u; // {u} at timelayer n
		double *u_p; // {u} at timelayer n+1
		double *u_m; // {u} at timelayer n+1
		double *u_tt; // second time derivative of {u} at timelayer n
		double *u_tt_p; // second time derivative of {u} at timelayer n+1
		double *u_t; // first time derivative of {u} at timelayer n
		double *u_t_p; // first time derivative of {u} at timelayer n+1
		double *K_eff;


		if(sch==0){

			u=new double[r_p]();
			u_p=new double[r_p]();
			u_m=new double[r_p]();
		}

		if(sch==1){

			u=new double[r_p]();
			u_p=new double[r_p]();
			u_tt=new double[r_p]();
			u_tt_p=new double[r_p]();
			u_t=new double[r_p]();
			u_t_p=new double[r_p]();
			K_eff=new double[r*r]();

			get_K_eff(r,M,K,K_eff,dt);

			inv(r,K_eff);
		}


		if(MPI_P_ID==0){
			std::cout<<"Solving [M]d2{u}/dt2+[K]{u}={F}"<<std::endl;
			std::cout<<std::endl;
			std::cout<<r_p<<std::endl;
		}
		

		//Loop for N_t timesteps
		//-------------------------------

		t=0;

		for(int n_t=0;n_t<100;n_t++){

			if(sch==1){
				t=t+dt;
			}
			
			//Get global force vector {F} at time t
			//------------------------------

			get_F(r,F,N_e,l,t);

			if(MPI_P_ID==0){

				//Get u at timelayer n+1
				//-------------------------------

				if(sch==0){
					get_u_p_explicit(r,r_p,u_p,u,u_m,M,K,F,dt,N_e,MPI_P_ID);
				}

				if(sch==1){
					get_u_p_implicit(r,r_p,u_p,u,u_t,u_t_p,u_tt,u_tt_p,M,K_eff,F,dt,N_e,MPI_P_ID);
				}

				//send to process 1

				if(MPI_N_P>1){

					u_buff[0]=u_p[3*(N_e/MPI_N_P-1)];
					u_buff[1]=u_p[3*(N_e/MPI_N_P-1)+1];
					u_buff[2]=u_p[3*(N_e/MPI_N_P-1)+2];

					MPI_Send(u_buff,3,MPI_DOUBLE,1,0,MPI_COMM_WORLD);
				}

			}

			if(MPI_P_ID==1){

				//receive from proceess 0

				MPI_Recv(u_buff,3,MPI_DOUBLE,0,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);

				u_p[0]=u_buff[0];
				u_p[1]=u_buff[1];
				u_p[2]=u_buff[2];

				//Get u at timelayer n+1
				//-------------------------------

				if(sch==0){
					get_u_p_explicit(r,r_p,u_p,u,u_m,M,K,F,dt,N_e,MPI_P_ID);
				}
				if(sch==1){
					get_u_p_implicit(r,r_p,u_p,u,u_t,u_t_p,u_tt,u_tt_p,M,K_eff,F,dt,N_e,MPI_P_ID);
				}

				//send to process 0

				u_buff[0]=u_p[6];
				u_buff[1]=u_p[7];
				u_buff[2]=u_p[8];

				MPI_Send(u_buff,3,MPI_DOUBLE,0,0,MPI_COMM_WORLD);

			}


			if(MPI_P_ID==0){

				//receive from process 1

				if(MPI_N_P>1){

					MPI_Recv(u_buff,3,MPI_DOUBLE,1,0,MPI_COMM_WORLD,MPI_STATUS_IGNORE);

					u_p[3*(N_e/MPI_N_P+1)]=u_buff[0];
					u_p[3*(N_e/MPI_N_P+1)+1]=u_buff[1];
					u_p[3*(N_e/MPI_N_P+1)+2]=u_buff[2];

				}

			}

			// Overwrite u at timelayer n-1 with u at timelayer n
			// and u at timelayer n with u at timelayer n+1
			//-------------------------------

			for(int i=0;i<r_p;i++){

				if(sch==0){
					u_m[i]=u[i];			
				}
								
				if(sch==1){
					u_tt[i]=u_tt_p[i];
					u_t[i]=u_t_p[i];
				}		

				u[i]=u_p[i];
			}

			if(sch==0){
				t=t+dt;
			}

		}

		if(MPI_P_ID==0){
			
			std::cout<<std::endl<<"Done!"<<std::endl;

			disp(r_p,1,u,"u");

			std::ofstream results_file;

			results_file.open("results.csv");

			if(results_file.good()){
				for(int i=0;i<r_p;i++){
					results_file<<u[i]<<"\n";
				}
				results_file.close();
			}

		}

	}else{
		MPI_Finalize();
		return 1;
	}


	MPI_Finalize();

	return 0;
}
